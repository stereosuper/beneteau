-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: May 22, 2019 at 02:34 PM
-- Server version: 5.6.37
-- PHP Version: 7.0.23-1~dotdeb+8.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbbeneteaugroupcom`
--

-- --------------------------------------------------------

--
-- Table structure for table `beneteau_yoast_seo_links`
--

DROP TABLE IF EXISTS `beneteau_yoast_seo_links`;
CREATE TABLE IF NOT EXISTS `beneteau_yoast_seo_links` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_id` bigint(20) UNSIGNED NOT NULL,
  `target_post_id` bigint(20) UNSIGNED NOT NULL,
  `type` varchar(8) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `link_direction` (`post_id`,`type`)
) ENGINE=InnoDB AUTO_INCREMENT=4695 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `beneteau_yoast_seo_links`
--

INSERT INTO `beneteau_yoast_seo_links` (`id`, `url`, `post_id`, `target_post_id`, `type`) VALUES
(1409, '#', 2, 0, 'internal'),
(1410, '#', 2, 0, 'internal'),
(1411, '#', 2, 0, 'internal'),
(1412, '#', 2, 0, 'internal'),
(1413, '#', 2, 0, 'internal'),
(1414, '#', 2, 0, 'internal'),
(1415, 'http://localhost/30-ans-aux-etats-unis/', 2, 0, 'external'),
(1416, '#', 2, 0, 'internal'),
(1417, '#', 2, 0, 'internal'),
(1418, 'http://beneteau.fr', 2, 0, 'external'),
(1419, 'http://beneteau.fr', 2, 0, 'external'),
(1420, 'http://beneteau.fr', 2, 0, 'external'),
(3110, '#', 86, 0, 'internal'),
(3111, 'http://localhost', 86, 72, 'internal'),
(3112, 'http://www.candidature-beneteau-group.com/', 86, 0, 'external'),
(3113, 'mailto:contact@beneteau-group.com', 86, 0, 'external'),
(3114, '#', 86, 0, 'internal'),
(3115, 'http://www.antigel.agency', 86, 0, 'external'),
(3164, 'http://localhost/savoir-faire/', 117289, 474, 'internal'),
(3165, 'http://localhost/marques-services/', 117289, 45, 'internal'),
(3557, 'https://teamvendeeformation.com/', 116956, 0, 'external'),
(3558, 'http://localhost/wp-content/uploads/2018/11/Marins-sans-frontières.jpg', 116956, 0, 'internal'),
(3559, 'http://localhost/wp-content/uploads/2018/11/vedette-diva.jpg', 116956, 0, 'internal'),
(3560, 'http://marins-sans-frontieres.org/', 116956, 0, 'external'),
(3561, 'http://www.grandlargue.org', 116956, 0, 'external'),
(3562, 'http://localhost/wp-content/uploads/2018/11/plisson-016-Fleury-Michon-JTA-Route-Rhum-.jpg', 116956, 0, 'internal'),
(3563, 'http://localhost/wp-content/uploads/2018/11/OF9.jpg', 116956, 0, 'internal'),
(3564, 'http://localhost/wp-content/uploads/2018/11/Canot-Maurice-dUrre.jpg', 116956, 0, 'internal'),
(3565, 'http://localhost/wp-content/uploads/2017/09/Rapport-dactivité-2016_Fondation-Beneteau.pdf', 116956, 0, 'internal'),
(3566, 'http://localhost/wp-content/uploads/2018/11/FONDATION-rapport-dactivité-2017-003.pdf', 116956, 0, 'internal'),
(3567, 'http://localhost/soumettre-un-projet/', 116956, 117211, 'internal'),
(3588, 'http://localhost/decouvrir-nos-metiers/', 4491864, 117289, 'internal'),
(3589, 'http://localhost/marques-services/', 4491864, 45, 'internal'),
(3658, 'http://localhost/histoire/', 116823, 101207, 'internal'),
(3659, 'http://localhost/innovation/', 116823, 476, 'internal'),
(3660, 'https://presse.beneteau-group.com/', 116823, 0, 'external'),
(3671, 'http://www.faar-atelier.com/', 117198, 0, 'external'),
(3672, 'http://www.veronique-braud.fr', 117198, 0, 'external'),
(3673, 'http://www.julienpulve.com', 117198, 0, 'external'),
(3674, 'mailto:info@fondation-beneteau.com', 117211, 0, 'external'),
(3888, 'mailto:contact@beneteau-group.com', 93, 0, 'external'),
(3889, 'http://localhost/emplois', 93, 0, 'internal'),
(3890, 'http://localhost/candidature/', 93, 402, 'internal'),
(3891, 'http://localhost/soumettre-un-projet/', 93, 117211, 'internal'),
(3892, 'http://www.beneteau.com/fr/contact', 93, 0, 'external'),
(3893, 'https://www.jeanneau.fr/contact/', 93, 0, 'external'),
(3894, 'https://www.cata-lagoon.com/fr/contact', 93, 0, 'external'),
(3895, 'https://www.prestige-yachts.fr/contact/', 93, 0, 'external'),
(3896, 'https://excess-catamarans.com/#top', 93, 0, 'external'),
(3897, 'http://www.montecarloyachts.it/fr/contacts', 93, 0, 'external'),
(3898, 'https://www.cnb-yachts.com/contact', 93, 0, 'external'),
(3899, 'http://www.fourwinns.com/intl/contact', 93, 0, 'external'),
(3900, 'http://www.glastron.com/intl/contact', 93, 0, 'external'),
(3901, 'http://www.scarabjetboats.com/intl/contact', 93, 0, 'external'),
(3902, 'http://www.wellcraft.com/intl/contact', 93, 0, 'external'),
(3903, 'https://fr.delphiayachts.eu/dy-pologne', 93, 0, 'external'),
(3904, 'https://www.bandofboats.com/fr/', 93, 0, 'external'),
(3905, 'https://www.sgb-finance.fr/devis-assurance-bateau.aspx', 93, 0, 'external'),
(3906, 'http://www.mobil-home.com/contacter-mobil-homes-irm.html', 93, 0, 'external'),
(3907, 'http://www.mobilhome-ohara.com/fr/contact', 93, 0, 'external'),
(3908, 'https://www.mobilhome-coco.com/contact', 93, 0, 'external'),
(3909, 'http://localhost/nous-rejoindre/', 4913160, 117744, 'internal'),
(4170, 'https://presse.beneteau-group.com/experts/jerome-de-metz.html', 4366135, 0, 'external'),
(4171, 'https://presse.beneteau-group.com/experts/louis-claude-roux.html', 4366135, 0, 'external'),
(4172, 'https://presse.beneteau-group.com/experts/annette-roux.html', 4366135, 0, 'external'),
(4173, 'https://presse.beneteau-group.com/experts/anne-leitzgen.html', 4366135, 0, 'external'),
(4174, 'https://press.beneteau-group.com/experts/yves-lyon-caen.html', 4366135, 0, 'external'),
(4175, 'https://presse.beneteau-group.com/experts/sebastien-moynot.html', 4366135, 0, 'external'),
(4176, 'https://presse.beneteau-group.com/experts/catherine-pourre.html', 4366135, 0, 'external'),
(4177, 'https://presse.beneteau-group.com/experts/herve-gastinel.html', 4366135, 0, 'external'),
(4178, 'https://presse.beneteau-group.com/experts/christophe-caudrelier.html', 4366135, 0, 'external'),
(4279, 'http://localhost/carriere/', 495, 569, 'internal'),
(4280, 'https://presse.beneteau-group.com/', 495, 0, 'external'),
(4281, 'http://localhost/decouvrir-nos-metiers/', 474, 117289, 'internal'),
(4282, 'http://localhost/marques-services/', 474, 45, 'internal'),
(4283, 'http://localhost/marques-services/', 476, 45, 'internal'),
(4284, 'http://localhost/vocation/', 476, 116823, 'internal'),
(4285, 'http://localhost/candidature/', 569, 402, 'internal'),
(4286, 'http://localhost/career/accastilleur-se/', 569, 4913713, 'internal'),
(4287, 'http://localhost/career/menuisier-agenceur/', 569, 4913824, 'internal'),
(4288, 'http://localhost/career/operateur-trice-composite/', 569, 4913983, 'internal'),
(4289, 'http://localhost/career/responsable-zone-commerciale/', 569, 4914064, 'internal'),
(4290, 'http://localhost/career/responsable-logistique/', 569, 4914113, 'internal'),
(4291, 'http://localhost/career/technicien-ne-methode-logistique/', 569, 4914197, 'internal'),
(4292, 'http://localhost/career/electricien-ne/', 569, 4914306, 'internal'),
(4293, 'http://localhost/career/approvisionneur-euse/', 569, 4914387, 'internal'),
(4294, 'http://localhost/career/chef-de-projet/', 569, 4914436, 'internal'),
(4295, 'http://localhost/career/manager-de-production/', 569, 4914488, 'internal'),
(4296, 'http://localhost/career/technicien-ne-qualite/', 569, 4914569, 'internal'),
(4297, 'http://localhost/career/concepteur-trice-be/', 569, 4914653, 'internal'),
(4298, 'http://localhost/career/mecanicien-ne-plombier/', 569, 4914702, 'internal'),
(4346, 'mailto:concours.beneteau@gmail.com', 116912, 0, 'external'),
(4347, 'http://localhost/wp-content/uploads/2018/10/Re╠çglement-concours-2019.pdf', 116912, 0, 'internal'),
(4348, 'http://localhost/wp-content/uploads/2018/10/FONDATION-BRIEF-CONCOURS-2019.pdf', 116912, 0, 'internal'),
(4349, 'http://localhost/wp-content/uploads/2018/10/Fiche-de-candidature-concours-camping.doc', 116912, 0, 'internal'),
(4661, 'https://presse.beneteau-group.com/experts/claude-brignon.html', 43, 0, 'external'),
(4662, 'http://localhost/wp-content/uploads/2019/04/CHARTE-ETHIQUE_FR-NUM-2019-04-10-BAT.pdf', 43, 0, 'internal'),
(4663, 'http://localhost/wp-content/uploads/2019/04/CHARTE-ETHIQUE-SLO-NUM-2019-04-10-BAT.pdf', 43, 0, 'internal'),
(4664, 'http://localhost/wp-content/uploads/2019/04/CHARTE-ETHIQUE-POL-NUM_2019-04-10-BAT.pdf', 43, 0, 'internal'),
(4665, 'http://localhost/wp-content/uploads/2019/04/CHARTE-ETHIQUE-IT-NUM_2019-04-10-BAT.pdf', 43, 0, 'internal'),
(4666, 'http://localhost/wp-content/uploads/2019/04/Cover-Code-of-Ethics.png', 43, 0, 'internal'),
(4667, 'http://localhost/carriere/', 43, 569, 'internal'),
(4668, 'http://localhost/vocation/', 43, 116823, 'internal'),
(4682, 'https://presse.beneteau-group.com/experts/jerome-de-metz.html', 78, 0, 'external'),
(4683, 'https://presse.beneteau-group.com/experts/louis-claude-roux.html', 78, 0, 'external'),
(4684, 'https://presse.beneteau-group.com/experts/annette-roux.html', 78, 0, 'external'),
(4685, 'https://presse.beneteau-group.com/experts/anne-leitzgen.html', 78, 0, 'external'),
(4686, 'https://presse.beneteau-group.com/experts/yves-lyon-caen.html', 78, 0, 'external'),
(4687, 'https://presse.beneteau-group.com/experts/sebastien-moynot.html', 78, 0, 'external'),
(4688, 'https://presse.beneteau-group.com/experts/catherine-pourre.html', 78, 0, 'external'),
(4689, 'https://presse.beneteau-group.com/experts/herve-gastinel.html', 78, 0, 'external'),
(4690, 'https://presse.beneteau-group.com/experts/christophe-caudrelier.html', 78, 0, 'external'),
(4691, 'https://presse.beneteau-group.com/actualites/rapport-dactivites-2017-2018-b0f4-ce95c.html', 78, 0, 'external'),
(4692, 'https://finances.beneteau-group.com/accueil', 78, 0, 'external'),
(4693, 'https://presse.beneteau-group.com/', 78, 0, 'external'),
(4694, 'http://localhost/marques-services/', 78, 45, 'internal');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

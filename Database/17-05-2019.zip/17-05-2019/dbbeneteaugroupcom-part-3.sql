-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: May 22, 2019 at 01:45 PM
-- Server version: 5.6.37
-- PHP Version: 7.0.23-1~dotdeb+8.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbbeneteaugroupcom`
--

-- --------------------------------------------------------

--
-- Table structure for table `beneteau_blogs`
--

DROP TABLE IF EXISTS `beneteau_blogs`;
CREATE TABLE IF NOT EXISTS `beneteau_blogs` (
  `blog_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `site_id` bigint(20) NOT NULL DEFAULT '0',
  `domain` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `path` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `public` tinyint(2) NOT NULL DEFAULT '1',
  `archived` tinyint(2) NOT NULL DEFAULT '0',
  `mature` tinyint(2) NOT NULL DEFAULT '0',
  `spam` tinyint(2) NOT NULL DEFAULT '0',
  `deleted` tinyint(2) NOT NULL DEFAULT '0',
  `lang_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`blog_id`),
  KEY `domain` (`domain`(50),`path`(5)),
  KEY `lang_id` (`lang_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `beneteau_blogs`
--

INSERT INTO `beneteau_blogs` (`blog_id`, `site_id`, `domain`, `path`, `registered`, `last_updated`, `public`, `archived`, `mature`, `spam`, `deleted`, `lang_id`) VALUES
(1, 1, 'localhost', '/', '2017-09-12 18:10:58', '2019-05-22 13:42:15', 1, 0, 0, 0, 0, 0),
(3, 1, 'localhost', '/en/', '2017-10-10 11:38:07', '2019-05-22 13:45:05', 1, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `beneteau_blog_versions`
--

DROP TABLE IF EXISTS `beneteau_blog_versions`;
CREATE TABLE IF NOT EXISTS `beneteau_blog_versions` (
  `blog_id` bigint(20) NOT NULL DEFAULT '0',
  `db_version` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `last_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`blog_id`),
  KEY `db_version` (`db_version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `beneteau_commentmeta`
--

DROP TABLE IF EXISTS `beneteau_commentmeta`;
CREATE TABLE IF NOT EXISTS `beneteau_commentmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `beneteau_comments`
--

DROP TABLE IF EXISTS `beneteau_comments`;
CREATE TABLE IF NOT EXISTS `beneteau_comments` (
  `comment_ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `beneteau_links`
--

DROP TABLE IF EXISTS `beneteau_links`;
CREATE TABLE IF NOT EXISTS `beneteau_links` (
  `link_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) UNSIGNED NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `beneteau_mlp_languages`
--

DROP TABLE IF EXISTS `beneteau_mlp_languages`;
CREATE TABLE IF NOT EXISTS `beneteau_mlp_languages` (
  `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `english_name` tinytext COLLATE utf8mb4_unicode_ci,
  `native_name` tinytext COLLATE utf8mb4_unicode_ci,
  `custom_name` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_rtl` tinyint(1) UNSIGNED DEFAULT '0',
  `iso_639_1` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `iso_639_2` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `wp_locale` tinytext COLLATE utf8mb4_unicode_ci,
  `http_name` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `priority` tinyint(1) UNSIGNED DEFAULT '10',
  PRIMARY KEY (`ID`),
  KEY `http_name` (`http_name`)
) ENGINE=InnoDB AUTO_INCREMENT=175 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `beneteau_mlp_languages`
--

INSERT INTO `beneteau_mlp_languages` (`ID`, `english_name`, `native_name`, `custom_name`, `is_rtl`, `iso_639_1`, `iso_639_2`, `wp_locale`, `http_name`, `priority`) VALUES
(1, 'Afar', 'Afaraf', '', 0, 'aa', 'aar', '', 'aa', 1),
(2, 'Avestan', 'avesta', '', 0, 'ae', 'ave', '', 'ae', 1),
(3, 'Afrikaans', 'Afrikaans', '', 0, 'af', 'afr', 'af', 'af-ZA', 1),
(4, 'Akan', 'Akan', '', 0, 'ak', 'aka', 'ak', 'ak', 1),
(5, 'Amharic', 'አማርኛ', '', 0, 'am', 'amh', '', 'am', 1),
(6, 'Aragonese', 'Aragonés', '', 0, 'an', 'arg', '', 'an', 1),
(7, 'Arabic', 'العربية', '', 1, 'ar', 'ara', 'ar', 'ar-AR', 1),
(8, 'Assamese', 'অসমীয়া', '', 0, 'as', 'asm', 'as', 'asm', 1),
(9, 'Asturian', 'Asturianu', '', 0, '', 'ast', 'ast', 'ast', 1),
(10, 'Avaric', 'авар мацӀ', '', 0, 'av', 'ava', '', 'av', 1),
(11, 'Aymara', 'aymar aru', '', 0, 'ay', 'aym', '', 'ay', 1),
(12, 'Azerbaijani', 'Azərbaycan dili', '', 0, 'az', 'aze', 'az', 'az-AZ', 1),
(13, 'South Azerbaijani', 'گؤنئی آذربایجان', '', 1, 'az', 'aze', 'azb', 'az', 1),
(14, 'Azerbaijani (Turkey)', 'Azərbaycan Türkcəsi', '', 1, 'az', 'aze', 'az_TR', 'az-TR', 1),
(15, 'Bashkir', 'башҡорт теле', '', 0, 'ba', 'bak', 'ba', 'ba', 1),
(16, 'Catalan (Balear)', 'Català (Balear)', '', 0, 'ca', 'cat', 'bal', 'ca', 1),
(17, 'Belarusian', 'Беларуская мова', '', 0, 'be', 'bel', 'bel', 'be-BY', 1),
(18, 'Bulgarian', 'Български', '', 0, 'bg', 'bul', 'bg_BG', 'bg-BG', 1),
(19, 'Bihari', 'भोजपुरी', '', 0, 'bh', 'bih', '', 'bh', 1),
(20, 'Bislama', 'Bislama', '', 0, 'bi', 'bis', '', 'bi', 1),
(21, 'Bambara', 'Bamanankan', '', 0, 'bm', 'bam', '', 'bm', 1),
(22, 'Bengali', 'বাংলা', '', 0, 'bn', 'ben', 'bn_BD', 'bn-BD', 1),
(23, 'Tibetan', 'བོད་སྐད', '', 0, 'bo', 'bod', 'bo', 'bo', 1),
(24, 'Breton', 'brezhoneg', '', 0, 'br', 'bre', '', 'br', 1),
(25, 'Bosnian', 'Bosanski', '', 0, 'bs', 'bos', 'bs_BA', 'bs-BA', 1),
(26, 'Catalan', 'Català', '', 0, 'ca', 'cat', 'ca', 'ca-ES', 1),
(27, 'Chechen', 'Нохчийн мотт', '', 0, 'ce', 'che', '', 'ce', 1),
(28, 'Chamorro', 'Chamoru', '', 0, 'ch', 'cha', '', 'ch', 1),
(29, 'Kurdish (Sorani)', 'كوردی‎', '', 0, 'ku', 'kur', 'ckb', 'ku', 1),
(30, 'Corsican', 'corsu', '', 0, 'co', 'cos', 'co', 'co', 1),
(31, 'Cree', 'ᓀᐦᐃᔭᐍᐏᐣ', '', 0, 'cr', 'cre', '', 'cr', 1),
(32, 'Czech', 'čeština‎', '', 0, 'cs', 'cze', 'cs_CZ', 'cs-CZ', 1),
(33, 'Kashubian', 'Kaszëbsczi', '', 0, '', 'csb', '', 'csb', 1),
(34, 'Church Slavic', 'ѩзыкъ словѣньскъ', '', 0, 'cu', 'chu', '', 'cu', 1),
(35, 'Chuvash', 'чӑваш чӗлхи', '', 0, 'cv', 'chv', '', 'cv', 1),
(36, 'Welsh', 'Cymraeg', '', 0, 'cy', 'cym', 'cy', 'cy-GB', 1),
(37, 'Danish', 'Dansk', '', 0, 'da', 'dan', 'da_DK', 'da-DK', 1),
(38, 'German', 'Deutsch', '', 0, 'de', 'deu', 'de_DE', 'de-DE', 1),
(39, 'Divehi', 'ދިވެހި', '', 1, 'dv', 'div', 'dv', 'dv', 1),
(40, 'Dzongkha', 'རྫོང་ཁ', '', 0, 'dz', 'dzo', '', 'dz', 1),
(41, 'Ewe', 'Eʋegbe', '', 0, 'ee', 'ewe', '', 'ee', 1),
(42, 'Greek (Polytonic)', 'Greek (Polytonic)', '', 0, '', 'grc', '', 'grc', 1),
(43, 'Greek', 'Ελληνικά', '', 0, 'el', 'ell', 'el', 'el-GR', 1),
(44, 'English', 'English', '', 0, 'en', 'eng', 'en_US', 'en-US', 1),
(45, 'English (Australia)', 'English (Australia)', '', 0, 'en', 'eng', 'en_AU', 'en-AU', 1),
(46, 'English (Canada)', 'English (Canada)', '', 0, 'en', 'eng', 'en_CA', 'en-CA', 1),
(47, 'English (UK)', 'English (UK)', '', 0, 'en', 'eng', 'en_GB', 'en-GB', 1),
(48, 'Esperanto', 'Esperanto', '', 0, 'eo', 'epo', 'eo', 'eo-EO', 1),
(49, 'Spanish (Chile)', 'Español de Chile', '', 0, 'es', 'spa', 'es_CL', 'es-CL', 1),
(50, 'Spanish (Mexico)', 'Español de México', '', 0, 'es', 'spa', 'es_MX', 'es-MX', 1),
(51, 'Spanish (Peru)', 'Español de Perú', '', 0, 'es', 'spa', 'es_PE', 'es-PE', 1),
(52, 'Spanish (Puerto Rico)', 'Español de Puerto Rico', '', 0, 'es', 'spa', 'es_PR', 'es-PR', 1),
(53, 'Spanish (Venezuela)', 'Español de Venezuela', '', 0, 'es', 'spa', 'es_VE', 'es-VE', 1),
(54, 'Spanish (Colombia)', 'Español de Colombia', '', 0, 'es', 'spa', 'es_CO', 'es-CO', 1),
(55, 'Spanish (Spain)', 'Español', '', 0, 'es', 'spa', 'es_ES', 'es-ES', 1),
(56, 'Estonian', 'Eesti', '', 0, 'et', 'est', 'et', 'et-EE', 1),
(57, 'Basque', 'Euskara', '', 0, 'eu', 'eus', 'eu', 'eu-ES', 1),
(58, 'Persian', 'فارسی', '', 1, 'fa', 'fas', 'fa_IR', 'fa-IR', 1),
(59, 'Persian (Afghanistan)', '(فارسی (افغانستان', '', 1, 'fa', 'eus', 'fa_AF', 'fa-AF', 1),
(60, 'Finnish', 'Suomi', '', 0, 'fi', 'fin', 'fi', 'fi-FI', 1),
(61, 'Fijian', 'vosa Vakaviti', '', 0, 'fj', 'fij', '', 'fj', 1),
(62, 'Faroese', 'føroyskt', '', 0, 'fo', 'fao', 'fo', 'fo-FO', 1),
(63, 'French (France)', 'Français', '', 0, 'fr', 'fra', 'fr_FR', 'fr-FR', 1),
(64, 'French (Belgium)', 'Français de Belgique', '', 0, 'fr', 'fra', 'fr_BE', 'fr-BE', 1),
(65, 'French (Canada)', 'Français du Canada', '', 0, 'fr', 'fra', '', 'fr-CA', 1),
(66, 'French (Switzerland)', 'Français de Suisse', '', 0, 'fr', 'fra', '', 'fr-CH', 1),
(67, 'Frisian', 'Frysk', '', 0, 'fy', 'fry', 'fy', 'fy-NL', 1),
(68, 'Irish', 'Gaelige', '', 0, 'ga', 'gle', '', 'ga-IE', 1),
(69, 'Scottish Gaelic', 'Gàidhlig', '', 0, 'gd', 'gla', 'gd', 'gd', 1),
(70, 'Galician', 'Galego', '', 0, 'gl', 'glg', 'gl_ES', 'gl-ES', 1),
(71, 'Guaraní', 'Avañe’ẽ', '', 0, 'gn', 'grn', 'gn', 'gn', 1),
(72, 'Swiss German', 'Schwyzerdütsch', '', 0, '', '', 'gsw', '', 1),
(73, 'Gujarati', 'ગુજરાતી', '', 0, 'gu', 'guj', '', 'gu', 1),
(74, 'Hausa', 'هَوُسَ', '', 1, 'ha', 'hau', '', 'ha', 1),
(75, 'Hawaiian', 'Ōlelo Hawaiʻi', '', 0, '', '', 'haw_US', 'haw-US', 1),
(76, 'Hazaragi', 'هزاره گی', '', 1, '', '', 'haz', '', 1),
(77, 'Hebrew', 'עִבְרִית', '', 1, 'he', 'heb', 'he_IL', 'he-IL', 1),
(78, 'Hindi', 'हिन्दी', '', 0, 'hi', 'hin', 'hi_IN', 'hi-IN', 1),
(79, 'Croatian', 'Hrvatski', '', 0, 'hr', 'hrv', 'hr', 'hr-HR', 1),
(80, 'Hungarian', 'Magyar', '', 0, 'hu', 'hun', 'hu_HU', 'hu-HU', 1),
(81, 'Armenian', 'Հայերեն', '', 0, 'hy', 'hye', 'hy', 'hy-AM', 1),
(82, 'Interlingua', 'Interlingua', '', 0, 'ia', 'ina', '', 'ia', 1),
(83, 'Indonesian', 'Bahasa Indonesia', '', 0, 'id', 'ind', 'id_ID', 'id-ID', 1),
(84, 'Inuktitut', 'ᐃᓄᒃᑎᑐᑦ', '', 0, 'iu', 'iku', '', 'iu', 1),
(85, 'Iloko', 'Pagsasao nga Iloko', '', 0, '', '', '', '', 1),
(86, 'Icelandic', 'Íslenska', '', 0, 'is', 'isl', 'is_IS', 'is-IS', 1),
(87, 'Italian', 'Italiano', '', 0, 'it', 'ita', 'it_IT', 'it-IT', 1),
(88, 'Japanese', '日本語', '', 0, 'ja', 'jpn', 'ja', 'ja-JP', 1),
(89, 'Javanese', 'Basa Jawa', '', 0, 'jv', 'jav', 'jv_ID', 'jv-ID', 1),
(90, 'Georgian', 'ქართული', '', 0, 'ka', 'kat', 'ka_GE', 'ka-GE', 1),
(91, 'Kinyarwanda', 'Kinyarwanda', '', 0, 'rw', 'kin', 'kin', 'rw', 1),
(92, 'Kazakh', 'Қазақ тілі', '', 0, 'kk', 'kaz', 'kk', 'kk', 1),
(93, 'Khmer', 'ភាសាខ្មែរ', '', 0, 'km', 'khm', '', 'km-KH', 1),
(94, 'Kannada', 'ಕನ್ನಡ', '', 0, 'kn', 'kan', 'kn', 'kn', 1),
(95, 'Korean', '한국어', '', 0, 'ko', 'kor', 'ko_KR', 'ko-KR', 1),
(96, 'Kashmiri', 'कश्मीरी', '', 0, 'ks', 'kas', '', 'ks', 1),
(97, 'Kurdish (Kurmanji)', 'Kurdî', '', 0, 'ku', 'kur', '', 'ku-TR', 1),
(98, 'Kyrgyz', 'кыргыз тили', '', 0, 'ky', 'kir', 'ky_KY', 'ky-KY', 1),
(99, 'Latin', 'latine', '', 0, 'la', 'lat', '', 'la-VA', 1),
(100, 'Luxembourgish', 'Lëtzebuergesch', '', 0, 'lb', 'ltz', 'lb_LU', 'lb-LU', 1),
(101, 'Limburgish', 'Limburgs', '', 0, 'li', 'lim', 'li', 'li', 1),
(102, 'Lao', 'ພາສາລາວ', '', 0, 'lo', 'lao', 'lo', 'lo', 1),
(103, 'Lithuanian', 'lietuvių kalba', '', 0, 'lt', 'lit', 'lt_LT', 'lt-LT', 1),
(104, 'Latvian', 'latviešu valoda', '', 0, 'lv', 'lav', 'lv', 'lv-LV', 1),
(105, 'Montenegrin', 'Crnogorski jezik', '', 0, 'me', '', 'me_ME', 'me-ME', 1),
(106, 'Malagasy', 'Malagasy', '', 0, 'mg', 'mlg', 'mg_MG', 'mg-MG', 1),
(107, 'Mari (Meadow)', 'олык марий', '', 0, '', '', '', '', 1),
(108, 'Macedonian', 'македонски јазик', '', 0, 'mk', 'mkd', 'mk_MK', 'mk-MK', 1),
(109, 'Malayalam', 'മലയാളം', '', 0, 'ml', 'mal', 'ml_IN', 'ml-IN', 1),
(110, 'Mongolian', 'Монгол', '', 0, 'mn', 'mon', '', 'mn', 1),
(111, 'Marathi', 'मराठी', '', 0, 'mr', 'mar', '', 'mr', 1),
(112, 'Maori', 'te reo Māori', '', 0, 'mi', 'mri', '', 'mi', 1),
(113, 'Mari (Hill)', 'кырык мары', '', 0, '', '', '', '', 1),
(114, 'Malay', 'bahasa Melayu', '', 0, 'ms', 'msa', 'ms_MY', 'ms-MY', 1),
(115, 'Mirandese', 'Mirandés', '', 0, '', '', '', '', 1),
(116, 'Burmese', 'ဗမာစာ', '', 0, 'my', 'mya', 'my_MM', 'my-MM', 1),
(117, 'Nepali', 'नेपाली', '', 0, 'ne', 'nep', 'ne_NP', 'ne-NP', 1),
(118, 'Norwegian (Bokmål)', 'Norsk bokmål', '', 0, 'nb', 'nob', 'nb_NO', 'nb-NO', 1),
(119, 'Dutch', 'Nederlands', '', 0, 'nl', 'nld', 'nl_NL', 'nl-NL', 1),
(120, 'Dutch (Belgium)', 'Nederlands (België)', '', 0, 'nl', 'nld', 'nl_BE', 'nl-BE', 1),
(121, 'Norwegian (Nynorsk)', 'Norsk nynorsk', '', 0, 'nn', 'nno', 'nn_NO', 'nn-NO', 1),
(122, 'Norwegian', 'Norsk', '', 0, 'no', 'nor', '', 'no', 1),
(123, 'Occitan', 'Occitan', '', 0, 'oc', 'oci', '', 'oc', 1),
(124, 'Ossetic', 'Ирон', '', 0, 'os', 'oss', 'os', 'os', 1),
(125, 'Panjabi', 'ਪੰਜਾਬੀ', '', 0, 'pa', 'pan', 'pa_IN', 'pa-IN', 1),
(126, 'Polish', 'Polski', '', 0, 'pl', 'pol', 'pl_PL', 'pl-PL', 1),
(127, 'Portuguese (Brazil)', 'Português do Brasil', '', 0, 'pt', 'por', 'pt_BR', 'pt-BR', 1),
(128, 'Portuguese (Portugal)', 'Português', '', 0, 'pt', 'por', 'pt_PT', 'pt-PT', 1),
(129, 'Pashto', 'پښتو', '', 1, 'ps', 'pus', 'ps', 'ps-AF', 1),
(130, 'Romanian', 'Română', '', 0, 'ro', 'ron', 'ro_RO', 'ro-RO', 1),
(131, 'Russian', 'Русский', '', 0, 'ru', 'rus', 'ru_RU', 'ru-RU', 1),
(132, 'Russian (Ukraine)', 'украї́нська мо́ва', '', 0, 'ru', 'rus', 'ru_UA', 'ru-UA', 1),
(133, 'Rusyn', 'Русиньскый', '', 0, '', '', 'rue', '', 1),
(134, 'Aromanian', 'Armãneashce', '', 0, '', 'rup', 'rup_MK', 'rup-MK', 1),
(135, 'Yakut', 'Sakha', '', 0, '', 'sah', 'sah', '', 1),
(136, 'Sanskrit', 'भारतम्', '', 0, 'sa', 'san', 'sa_IN', 'sa-IN', 1),
(137, 'Sindhi', 'سندھ', '', 0, 'sd', 'snd', 'sd_PK', 'sd-PK', 1),
(138, 'Sinhala', 'සිංහල', '', 0, 'si', 'sin', 'si_LK', 'si-LK', 1),
(139, 'Slovak', 'Slovenčina', '', 0, 'sk', 'slk', 'sk_SK', 'sk-SK', 1),
(140, 'Slovenian', 'slovenščina', '', 0, 'sl', 'slv', 'sl_SI', 'sl-SI', 1),
(141, 'Somali', 'Afsoomaali', '', 0, 'so', 'som', 'so_SO', 'so-SO', 1),
(142, 'Albanian', 'Shqip', '', 0, 'sq', 'sqi', 'sq', 'sq-AL', 1),
(143, 'Serbian', 'Српски језик', '', 0, 'sr', 'srp', 'sr_RS', 'sr-RS', 1),
(144, 'Sardinian', 'sardu', '', 0, 'sc', 'srd', 'srd', 'sc', 1),
(145, 'Sundanese', 'Basa Sunda', '', 0, 'su', 'sun', 'su_ID', 'su-ID', 1),
(146, 'Swedish', 'Svenska', '', 0, 'sv', 'swe', 'sv_SE', 'sv-SE', 1),
(147, 'Swahili', 'Kiswahili', '', 0, 'sw', 'swa', 'sw', 'sw-KE', 1),
(148, 'Tamil', 'தமிழ்', '', 0, 'ta', 'tam', 'ta_IN', 'ta-IN', 1),
(149, 'Tamil (Sri Lanka)', 'தமிழ்', '', 0, 'ta', 'tam', 'ta_LK', 'ta-LK', 1),
(150, 'Telugu', 'తెలుగు', '', 0, 'te', 'tel', 'te', 'te-IN', 1),
(151, 'Tajik', 'тоҷикӣ', '', 0, 'tg', 'tgk', 'tg', 'tg', 1),
(152, 'Thai', 'ไทย', '', 0, 'th', 'tha', 'th', 'th-TH', 1),
(153, 'Klingon', 'TlhIngan', '', 0, '', '', 'tlh', 'tlh', 1),
(154, 'Tagalog', 'Tagalog', '', 0, 'tl', 'tgl', 'tl', 'tl-PH', 1),
(155, 'Turkish', 'Türkçe', '', 0, 'tr', 'tur', 'tr_TR', 'tr-TR', 1),
(156, 'Tatar', 'Татар теле', '', 0, 'tt', 'tat', 'tt_RU', 'tt-RU', 1),
(157, 'Turkmen', 'Türkmençe', '', 0, 'tk', 'tuk', 'tuk', 'tk', 1),
(158, 'Tamazight (Central Atlas)', 'ⵜⴰⵎⴰⵣⵉⵖⵜ', '', 0, '', '', 'tzm', '', 1),
(159, 'Udmurt', 'удмурт кыл', '', 0, '', '', '', '', 1),
(160, 'Uyghur', 'Uyƣurqə', '', 0, 'ug', 'uig', 'ug_CN', 'ug-CN', 1),
(161, 'Ukrainian', 'Українська', '', 0, 'uk', 'ukr', 'uk', 'uk-UA', 1),
(162, 'Urdu', 'اردو', '', 0, 'ur', 'urd', 'ur', 'ur', 1),
(163, 'Uzbek', 'O‘zbekcha', '', 0, 'uz', 'uzb', 'uz_UZ', 'uz-UZ', 1),
(164, 'Venetian', 'vèneta', '', 0, '', '', '', '', 1),
(165, 'Vietnamese', 'Tiếng Việt', '', 0, 'vi', 'vie', 'vi', 'vi-VN', 1),
(166, 'Walloon', 'Walon', '', 0, 'wa', 'wln', 'wa', 'wa', 1),
(167, 'Mingrelian', 'მარგალური ნინა', '', 0, '', '', 'xmf', '', 1),
(168, 'Yiddish', 'ייִדיש', '', 1, 'yi', 'yid', '', 'yi', 1),
(169, 'Yorùbá', 'èdè Yorùbá', '', 0, 'yo', 'yor', '', 'yo', 1),
(170, 'Chinese (China)', '中文', '', 0, 'zh', 'zho', 'zh_CN', 'zh-CN', 1),
(171, 'Chinese (Hong Kong)', '香港中文版	', '', 0, 'zh', 'zho', 'zh_HK', 'zh-HK', 1),
(172, 'Chinese (Singapore)', '中文', '', 0, 'zh', 'zho', '', 'zh-SG', 1),
(173, 'Chinese (Taiwan)', '中文', '', 0, 'zh', 'zho', 'zh_TW', 'zh-TW', 1),
(174, 'Chinese', '中文', '', 0, 'zh', 'zho', '', 'zh', 1);

-- --------------------------------------------------------

--
-- Table structure for table `beneteau_mlp_site_relations`
--

DROP TABLE IF EXISTS `beneteau_mlp_site_relations`;
CREATE TABLE IF NOT EXISTS `beneteau_mlp_site_relations` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `site_1` bigint(20) NOT NULL,
  `site_2` bigint(20) NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `site_combinations` (`site_1`,`site_2`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `beneteau_mlp_site_relations`
--

INSERT INTO `beneteau_mlp_site_relations` (`ID`, `site_1`, `site_2`) VALUES
(2, 1, 3);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
